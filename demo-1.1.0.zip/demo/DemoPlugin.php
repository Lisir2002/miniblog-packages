<?php
declare(strict_types=1);
namespace Wx\Plugins\demo;

use Wx\Contracts\PackageInterface;
use Wx\Core\Kernel;

/** GitHub 发版源验证插件 v1.1.0 —— 装配即登记，不做任何事。 */
final class DemoPlugin implements PackageInterface
{
    public const VERSION = '1.1.0';

    public function slug(): string { return 'demo'; }

    public function register(Kernel $kernel): void
    {
        // 验证用占位：升级 / 回滚流程只关心文件与状态切换，不订阅任何钩子。
    }
}
